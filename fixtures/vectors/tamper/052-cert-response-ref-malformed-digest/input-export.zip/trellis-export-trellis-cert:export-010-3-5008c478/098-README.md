# Trellis Export — export/010-certificate-of-completion-inline

Three-event chain (binding + SignatureAffirmation + certificate) plus `065-certificates-of-completion.cbor` bound via `trellis.export.certificates-of-completion.v1`. ADR 0007 §"Export manifest catalog" reference shape. Tamper: SignatureAffirmation signedPayloadDigest non-hex (tamper/052).
