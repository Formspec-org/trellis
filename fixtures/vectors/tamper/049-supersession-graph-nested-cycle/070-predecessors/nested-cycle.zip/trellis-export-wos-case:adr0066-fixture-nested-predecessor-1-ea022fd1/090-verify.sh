#!/bin/sh
set -eu
